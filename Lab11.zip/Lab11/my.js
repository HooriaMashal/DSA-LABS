document.getElementById("nameInput").addEventListener("keyup", function() {
  let name = this.value.trim();
  document.getElementById("greeting").textContent =
    name ? "Hello, " + name + "!" : "Hello, Friend!";
});

document.getElementById("moodSelect").addEventListener("change", function() {
  let mood = this.value;
  let bg = document.body;

  if (mood === "happy") bg.style.backgroundColor = "#fff89a";
  else if (mood === "sad") bg.style.backgroundColor = "#9fd3c7";
  else if (mood === "angry") bg.style.backgroundColor = "#fca5a5";
  else if (mood === "confused") bg.style.backgroundColor = "#d3d3d3";
  else bg.style.backgroundColor = "#f2f2f2";
});

document.getElementById("changeMoodBtn").addEventListener("click", function() {
  let mood = document.getElementById("moodSelect").value;
  let emoji = document.getElementById("emoji");

  if (mood === "happy") emoji.textContent = "😊";
  else if (mood === "sad") emoji.textContent = "😢";
  else if (mood === "angry") emoji.textContent = "😡";
  else if (mood === "confused") emoji.textContent = "😕";
  else emoji.textContent = "🙂";
});

let emoji = document.getElementById("emoji");
emoji.addEventListener("mouseover", function() {
  emoji.style.transform = "scale(1.5)";
});
emoji.addEventListener("mouseout", function() {
  emoji.style.transform = "scale(1)";
});

