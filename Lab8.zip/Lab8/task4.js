let marks = [67, 33, 90, 55, 25];

let passed = marks.filter(function(mark) {
  return mark > 50;
});

console.log("Marks greater than 50:", passed);
