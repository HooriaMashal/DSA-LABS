let nums = [2, 3, 4, 5];

let product = nums.reduce(function(acc, value) {
  return acc * value;
}, 1);

console.log("Product of all numbers:", product);
