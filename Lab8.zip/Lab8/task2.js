const toSec = (minutes) => {
  return minutes * 60;
};

console.log("Seconds:", toSec(9));
