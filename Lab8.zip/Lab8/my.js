function findLargest(a, b, c) {
  if (a > b && a > c) {
    console.log(a + " is the largest number");
  } else if (b > a && b > c) {
    console.log(b + " is the largest number");
  } else if (c > a && c > b) {
    console.log(c + " is the largest number");
  } else {
    console.log("All numbers are equal");
  }
}
findLargest(10, 20, 30);
