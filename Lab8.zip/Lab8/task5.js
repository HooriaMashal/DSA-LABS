let n = prompt("Enter the size of array:");
n = Number(n);

let numbers = [];

for (let i = 1; i <= n; i++) {
  numbers.push(i);
}

console.log("Array of numbers:", numbers);
