console.log("Web APP dEV");
fullName = "Hooria Mashal";
age = 19;
price = 99.99;
radius = 14;
a = null;
y = undefined;
console.log(a);
console.log(y);


var time = 10;
if(time>5 && time <17){
   console.log("Good Morning");
} else{
    console.log("Good Evening");
}