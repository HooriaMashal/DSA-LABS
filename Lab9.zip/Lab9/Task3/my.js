let p = document.getElementsByClassName("para");
p[0].innerText = "Hello!";
p[1].innerText = "Web Class.";

