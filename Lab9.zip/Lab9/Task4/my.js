let listItems = document.querySelectorAll("#myList li");
listItems.forEach(function(item) {
  item.textContent = item.textContent.toUpperCase();
});
