let p = document.getElementsByClassName("para");
p[0].innerHTML = "This is a <b>bold</b> paragraph";

