let p = document.getElementsByClassName("para");

for (let i = 0; i < p.length; i++) {
  p[i].style.color = "blue";
}
