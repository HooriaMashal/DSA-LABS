function toggleBulb() {
  let bulb = document.getElementById("bulb");
  if (bulb.src.includes("off.jpg")) {
    bulb.setAttribute("src", "on.jpg");
  } else {
    bulb.setAttribute("src", "off.jpg");
  }
}
