function toggleText() {
  let para = document.getElementById("text");
  if (para.style.display === "none") {
    para.style.display = "block";
  } else {
    para.style.display = "none";
  }
}
