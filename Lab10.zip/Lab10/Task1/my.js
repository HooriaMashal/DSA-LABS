let para = document.querySelector(".oldClass");
let oldName = para.getAttribute("class");
console.log("Old class name:", oldName);

para.setAttribute("class", "newClass");
console.log("New class name:", para.getAttribute("class"));
