let btn = document.createElement("button");
btn.textContent = "Log In";
btn.style.backgroundColor = "blue";
btn.style.color = "white";
btn.style.padding = "10px";
btn.style.borderRadius = "5px";
document.documentElement.prepend(btn);
