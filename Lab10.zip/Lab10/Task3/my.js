let p = document.querySelector(".para");
p.classList.add("highlight");
