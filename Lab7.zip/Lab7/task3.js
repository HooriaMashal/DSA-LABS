let nums = [15, 7, 22, 3, 40, 9];
let max = nums[0];
let min = nums[0];

for (let num of nums) {
  if (num > max) max = num;
  if (num < min) min = num;
}

console.log("Max number is:", max);
console.log("Min number is:", min);