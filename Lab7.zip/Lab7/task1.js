let numbers = [2, 5, 9, 10, 11, 14, 20];
let evens = [];

for (let num of numbers) {
  if (num % 2 === 0) {
    evens.push(num);
  }
}
console.log("Even Numbers:", evens);
