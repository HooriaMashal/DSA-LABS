let fruits = ["apple", "banana", "mango"];
let upperFruits = [];

for (let fruit of fruits) {
  upperFruits.push(fruit.toUpperCase());
}

console.log("Uppercase Array:", upperFruits);
