let softwareHouses = ["A", "B", "C", "D"];

softwareHouses.shift();
softwareHouses.splice(1, 1, "E");
softwareHouses.push("F");

console.log("Updated Software Houses:", softwareHouses);
